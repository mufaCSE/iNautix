import java.util.*;
 public class Prog6
 {
 public static void main(String[] args)
 {
	String a= new String();
	Scanner sc=new Scanner(System.in);
	a=sc.nextLine();
	int sum=0;
	for(int i=0;i<a.length();i++)
	{
	 if(Character.isDigit(a.charAt(i)))
	     sum+=Integer.parseInt(String.valueOf(a.charAt(i)));
	
	}
	System.out.println(sum);
 }
}