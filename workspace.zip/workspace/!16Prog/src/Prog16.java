import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.Map.Entry;


public class Prog16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		HashMap<String,String> hm=new HashMap<String,String>();
		int i,n;
		System.out.print("Enter number of strings");
		n=in.nextInt();
		String input[]=new String[n];
		for(i=0;i<input.length;i++)
		{
			input[i]=in.next();
		}
		i=0;
		for(i=0;i<input.length;i++)
		{
			String temp=input[i];
			hm.put(String.valueOf(temp.charAt(0)),String.valueOf(temp.charAt(temp.length()-1)));
		}
		in.close();
		Set<Entry<String,String>> s=hm.entrySet();
		Iterator<Entry<String,String>> it=s.iterator();
		while(it.hasNext())
		{
			String key=it.next().getKey();
			System.out.println(key+":"+hm.get(key));
		}


	}

}
