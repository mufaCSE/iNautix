import java.util.*;
 public class Prog1
 {
  public static void main(String[] args)
    {
	Scanner sc= new Scanner(System.in);
	int n,count=0;
	n=sc.nextInt();
	int[] a= new int[n];
	for(int i=0;i<n;i++)
	{
	a[i]=sc.nextInt();
	}
	for(int i=0;i<n;i++)
	{
	if(a[i]==6 &&(a[i+1]==6 || a[i+1]==7))
	    count++;
	}
	System.out.println(count);
	}
 }