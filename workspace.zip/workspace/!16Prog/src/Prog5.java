import java.util.*;
 public class Prog5
 {
  public static void main(String[] args)
    {
	Scanner sc= new Scanner(System.in);
	int a=sc.nextInt();
	int b=sc.nextInt();
	int c=sc.nextInt();
	int z;
	z=rSum(a)+rSum(b)+rSum(c);
	System.out.println(z);
	}
	public static int rSum(int d)
	{
	  int temp;
	  temp=d%10;
	  if(temp < 5)
	   d=d-temp;
	  else
	   d=d+(10-temp);
	  return d;
	}
}