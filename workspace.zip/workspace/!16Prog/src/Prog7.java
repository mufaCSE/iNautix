import java.util.*;
public class Prog7
{
	public static void main (String[] args)
	{
		Scanner sc=new Scanner(System.in);
		String s;
		String a=" ";
		s=sc.nextLine();
		int i=0;
		int j= s.length()-1;
		while(i<j)
		{
			if(s.charAt(i)==s.charAt(j))
			{
				if(i==j)
				{
					a+=s.charAt(i)+a;
				}
				else
				{
					a+=s.charAt(i);
				}
			}
			i++;
			j--;
		}
		System.out.println(a);
	}
}