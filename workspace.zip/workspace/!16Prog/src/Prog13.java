import java.util.*;
public class Prog13
{
	public static void main(String[] args)
	{
			Scanner sc=new Scanner(System.in);
			int n;
			n=sc.nextInt();
			int[] a=new int[n];
			for(int i=0;i<n;i++)
			{
				a[i]=sc.nextInt();
			}
			int i=0;
			int j=n-1;
			int sum1=a[i];
			int sum2=a[n-1];
			while(i<j)
			{
				if(sum1==sum2 && j==i+1)
				{
					System.out.println("True");
					System.exit(0);
				}
				if(sum1==sum2)
				{
					i++;
					sum1+=a[i];
					j--;
					sum2+=a[j];
				}
				if(sum1>sum2)
				{
					sum2+=a[--j];
				}
				else
				{
					sum1+=a[i++];
				}
			     
			}
			System.out.println("False");
	}
}