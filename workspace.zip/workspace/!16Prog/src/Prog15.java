 import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.Map.Entry;


public class Prog15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		HashMap<String,Boolean> hm=new HashMap<String,Boolean>();
		int i,j;
		String input;
		input=in.next();
		
		for(i=0;i<input.length()-1;i++)
		{
			for(j=i+1;j<input.length();j++)
			{
				if(input.charAt(i)==input.charAt(j))
				{
					hm.put(String.valueOf(input.charAt(i)), true);
					break;
				}
			}
			if(j==input.length() && !hm.containsKey(String.valueOf(input.charAt(i))))
				hm.put(String.valueOf(input.charAt(i)), false);
		}
		if(i==input.length()-1 && !hm.containsKey(String.valueOf(input.charAt(i))))
		{
			hm.put(String.valueOf(input.charAt(i)), false);
		}
		Set<Entry<String,Boolean>> s=hm.entrySet();
		Iterator<Entry<String,Boolean>> it=s.iterator();
		while(it.hasNext())
		{
			String key=it.next().getKey();
			System.out.println(key+":"+hm.get(key));
		}
		
	}

}
