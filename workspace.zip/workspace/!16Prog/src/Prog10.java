import java.util.*;
public class Prog10
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int n,sum=0,avg;
		n=sc.nextInt();
		int[] a= new int[n];
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		Arrays.sort(a);
		for(int i=1;i<=n-2;i++)
		{
			sum=sum+a[i];
		}
		avg=sum/(n-2);
		System.out.println(avg);
	}
}