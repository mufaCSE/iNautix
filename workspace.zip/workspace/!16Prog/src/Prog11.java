import java.util.*;
public class Prog11
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		String s;
		char a=' ';
		s=sc.next();
		for(int i=0;i<s.length();i++)
		{
			if(a==s.charAt(i))
			{
				continue;
			}
			else
			{
				a=s.charAt(i);
				System.out.print(a);
			}
		}
		
	}
}