import java.util.*;
public class Prog9
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int n,c1=0,c2=0;
		n=sc.nextInt();
		int[] a=new int[n];
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		for(int i=0;i<n;i++)
		{
			if(a[i]==1)
			 c1++;
			if(a[i]==4)
			 c2++;
		}
		if(c1>c2)
			System.out.println("True");
		if(c1<c2)
			System.out.println("False");
		
	}
}