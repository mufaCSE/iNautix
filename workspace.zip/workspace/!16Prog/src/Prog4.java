import java.util.*;
import java.lang.*;
 public class Prog4
 {
  public static void main(String[] args)
    {
	Scanner sc= new Scanner(System.in);
	
	int a=sc.nextInt();
	int b=sc.nextInt();
	int c=sc.nextInt();
	int x= Math.abs(a-b);
	int y= Math.abs(a-c);
	int z= Math.abs(b-c);
	if(x <=1 && y >=2 && z>=2)
	{
	  System.out.println("True");
	
	}
	else if((z<=1 && x>=2 && y>=2) )
	 {  
	   System.out.println("True");
	}
	else if((y<=1 && z>=2 && x>=2))
	 {
	 System.out.println("True");
	}
	else
	  System.out.println("False");
	
	}
	
}