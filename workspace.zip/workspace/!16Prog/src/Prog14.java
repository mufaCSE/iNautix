import java.util.*;

public class Prog14
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		HashMap<String,String> hm=new HashMap<String,String>();
		int n;
		n=sc.nextInt();
		for(int i=0;i<n;i++)
		{
			hm.put(sc.next(),sc.next());
		}
		if(n==2)
		{
			hm.put("ab",hm.get("a")+hm.get("b"));
		}
		
		Set s=hm.entrySet();
		Iterator it=s.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}
}