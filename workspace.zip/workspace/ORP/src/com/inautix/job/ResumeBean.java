package com.inautix.job;

public class ResumeBean 
{
	public String ApId;
	public String FilePath;
	public String getApId() {
		return ApId;
	}
	public void setApId(String apId) {
		ApId = apId;
	}
	public String getFilePath() {
		return FilePath;
	}
	public void setFilePath(String filePath) {
		FilePath = filePath;
	}
}
