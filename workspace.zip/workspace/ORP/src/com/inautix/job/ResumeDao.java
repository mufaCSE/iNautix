package com.inautix.job;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ResumeDao 
{
	static ConnectionManager conn;
	static Statement stmt;
	static PreparedStatement pst;
	public ResumeDao()
	{
		conn=new ConnectionManager();
		stmt=null;
		pst=null;
	}
	public  int uploadResume(ResumeBean r)
	{
		String query;
		int status=0;
		try {
			
			query="insert into T_XBBNHG1_Resume values(?,?)";
			pst=conn.connectionHelper().prepareStatement(query);
			pst.setString(1, r.getApId());
			pst.setString(2, r.getFilePath());
			
			
			status=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				if(pst!= null)
				pst.close();
				
				if(conn != null)
				  conn.connectionHelper().close();
			}catch(Exception e)
			{
				
			}
		}
		
		return status;
		}
	
public static List ApplicantList(){
		
		
		List<ResumeBean> JobApplicantList = null;
		
		ResultSet rs=null;
		try {
			
			 stmt = conn.connectionHelper().createStatement();
			 String searchquery="Select ApId from T_XBBNHG1_JobApp";
			 JobApplicantList=new ArrayList<ResumeBean>();
			 pst=conn.connectionHelper().prepareStatement(searchquery);
				
			//pst.setString(1, j.getStream());
			rs=pst.executeQuery();
			 while(rs.next())
			 {
				ResumeBean rb =new ResumeBean();
				rb.setApId(rs.getString(1));
				//jb.setPosition(rs.getString(2));
				//jb.setCompany(rs.getString(3));
				//jb.setStream(rs.getString(4));
				//jb.setSalary(rs.getInt(5));
				
				JobApplicantList.add(rb);
				
			 }
			
			
			}
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		finally{
			try {
				if(rs!= null)
				rs.close();
				if(stmt != null)					
				stmt.close();				
				//conn.commit();
				if(conn != null)
				  conn.connectionHelper().close();
			}catch(Exception e)
			{
				
			}
		}
		
			return JobApplicantList;
	}
}
