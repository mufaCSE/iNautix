package com.inautix.job;

public class jobAppBean {

	public String ApId;
	public String Name;
	public int Age;
	public String Qualifications;
	public String Gender;
	public String DoB;
	public String Uname;
	public String pwd;
	
	public String getUname() {
		return Uname;
	}
	public void setUname(String uname) {
		Uname = uname;
	}
	public String getPwd() {
		return pwd;
	}
	
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getApId() {
		return ApId;
	}
	public void setApId(String apId) {
		ApId = apId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public String getQualifications() {
		return Qualifications;
	}
	public void setQualifications(String qualifications) {
		Qualifications = qualifications;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getDoB() {
		return DoB;
	}
	public void setDoB(String doB) {
		DoB = doB;
	}
}
