package com.inautix.job;

public class TestBean 
{
	public String ApId;
	public String Stream;
	public String Qid;
	public String ans;
	public String Questions;
	public String Options;
	public String Answers;
	public int Marks;
	
	public String getAns()
	{
		return ans;
	}
	public void setAns(String ans)
	{
		this.ans = ans;
	}
	public String getApId() 
	{
		return ApId;
	}
	public void setApId(String apId)
	{
		ApId = apId;
	}
	public String getStream() 
	{
		return Stream;
	}
	public void setStream(String stream)
	{
		Stream = stream;
	}
	public String getQid() 
	{
		return Qid;
	}
	public void setQid(String qid)
	{
		Qid = qid;
	}
	public String getQuestions() 
	{
		return Questions;
	}
	public void setQuestions(String questions)
	{
		Questions = questions;
	}
	public String getOptions()
	{
		return Options;
	}
	public void setOptions(String options)
	{
		Options = options;
	}
	public String getAnswers()
	{
		return Answers;
	}
	public String setAnswers(String answers) 
	{
		return Answers = answers;
	}
	public int getMarks() 
	{
		return Marks;
	}
	public void setMarks(int marks)
	{
		Marks = marks;
	}
	
	
}
