package com.inautix.job;

//package com.inautix.job;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.inautix.job.ConnectionManager;

public class JobAppDao {


		static ConnectionManager conn;
		static Statement stmt;
		PreparedStatement pst;
		//Connection con;
		public JobAppDao()
		{
			conn=new ConnectionManager();
			stmt=null;
			pst=null;
		}
/*	public static List jobAppDet(){
		
		//step 3: create statement object 
		List JobList = null;
		
		ResultSet rs=null;
		try {
			
			 stmt = conn.connectionHelper().createStatement();
			 String searchquery="Select * from T_XBBNHG1_JobApp";
			 rs = stmt.executeQuery(searchquery);
			 JobList=new ArrayList<jobAppBean>();
			 while(rs.next())
			 {
				jobAppBean jb =new jobAppBean();
				jb.setApId(rs.getString(1));
				jb.setName(rs.getString(2));
				jb.setAge(rs.getInt(3));
				jb.setQualifications(rs.getString(4));
				jb.setGender(rs.getString(5));
				jb.setDoB(rs.getString(6));
				jb.setUname(rs.getString(6));
				jb.setPwd(rs.getString(6));
				JobList.add(jb);
			 }
			
			
			}
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		finally{
			try {
				if(rs!= null)
				rs.close();
				if(stmt != null)					
				stmt.close();				
				//conn.commit();
				if(conn != null)
				  conn.connectionHelper().close();
			}catch(Exception e)
			{
				
			}
		}
		
			return JobList;
	}*/
	
	
	public  int addJobApp(jobAppBean j)
	{
		String query;
		int status=0;
		try {
			
			query="insert into T_XBBNHG1_JobApp values(?,?,?,?,?,?,?,?)";
			pst=conn.connectionHelper().prepareStatement(query);
			pst.setString(1, j.getApId());
			pst.setString(2, j.getName());
			pst.setInt(3, j.getAge());
			pst.setString(4, j.getQualifications());
			pst.setString(5, j.getGender());
			pst.setString(6, j.getDoB());
			pst.setString(6, j.getUname());
			pst.setString(6, j.getPwd());
			
			status=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				if(pst!= null)
				pst.close();
				
				if(conn != null)
				  conn.connectionHelper().close();
			}catch(Exception e)
			{
				
			}
		}
		
		return status;
		}
	
	
	public  int updateJob(jobAppBean j)
	{
		String query;
		int status=0;
		try {
			
			query="update T_XBBNHG1_JobApp set pwd=? where ApId=?";
			pst=conn.connectionHelper().prepareStatement(query);
			
			pst.setString(1, j.getPwd());
			pst.setString(2, j.getApId());
			
			
			status=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				if(pst!= null)
				pst.close();
				if(conn != null)
				  conn.connectionHelper().close();
			}catch(Exception e)
			{
				
			}
		}
		return status;
		}
		
		
	
	
	
	
	
}
