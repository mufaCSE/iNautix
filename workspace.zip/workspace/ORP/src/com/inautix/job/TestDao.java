package com.inautix.job;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TestDao
{
	static ConnectionManager conn;
	static Statement stmt;
	static PreparedStatement pst;
	public TestDao()
	{
		conn=new ConnectionManager();
		stmt=null;
		pst=null;
	}
	public static List QuestionList(TestBean t)
	{
		List QuestionList = null;
		
		ResultSet rs=null;
		try {
			
			 stmt = conn.connectionHelper().createStatement();
			 String searchquery="Select Qid,Questions,options from T_XBBNHG1_Questions where stream=?";
			 QuestionList=new ArrayList<TestBean>();
			 pst=conn.connectionHelper().prepareStatement(searchquery);
				
			pst.setString(1, t.getStream());
			rs=pst.executeQuery();
			while(rs.next())
			 {
				TestBean tb =new TestBean();
				tb.setQid(rs.getString(1));
				tb.setQuestions(rs.getString(2));
				tb.setOptions(rs.getString(3));
				
				
				QuestionList.add(tb);
				
			 }
			}
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
			finally{
				try {
					if(rs!= null)
					rs.close();
					if(stmt != null)					
					stmt.close();				
					//conn.commit();
					if(conn != null)
					  conn.connectionHelper().close();
				}catch(Exception e)
				{
					
				}
			}
		return QuestionList;
		
	}
	public String Answers(TestBean t)
	{
		//List QuestionList = null;
		
		ResultSet rs=null;
		 String getans=null;
			
		try {
			
			 stmt = conn.connectionHelper().createStatement();
			 String searchquery="Select Answer from T_XBBNHG1_Answers where Qid=?";
			// QuestionList=new ArrayList<TestBean>();
			 pst=conn.connectionHelper().prepareStatement(searchquery);
			
			pst.setString(1, t.getQid());
			rs=pst.executeQuery();
			while(rs.next())
			 {
				TestBean tb =new TestBean();
				 getans=tb.setAnswers(rs.getString(1));
			 }
			}
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
			finally{
				try {
					if(rs!= null)
					rs.close();
					if(stmt != null)					
					stmt.close();				
					//conn.commit();
					if(conn != null)
					  conn.connectionHelper().close();
				}catch(Exception e)
				{
					
				}
			}
		
		return getans;
		
	}
}
