package job;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


import com.inautix.job.TestBean;
import com.inautix.job.TestDao;


public class TestApp 
{
	public static void main(String[] args)
	{	
		
		Scanner in =new Scanner(System.in);
		String stream;
		int anscount=0,quescount=0,marks;
		TestBean tb=new TestBean();
		TestDao td=new TestDao();
		System.out.print("Online Test....:\t");
		System.out.println("\nChose the Stream...!!\t");
		System.out.println("IT||MECH||CIVIL||EEE||ECE");
		stream=in.next();
		tb.setStream(stream);
		
		
		List<TestBean> jbl = null;
		jbl= td.QuestionList(tb);
		Iterator<TestBean> ir =  jbl.iterator();
			while(ir.hasNext())
			{
				TestBean tbB = ir.next();
				System.out.println("Qid--------------------------Question---------------------------------------------------------------------Options");
				System.out.println("__________________________________________________________________________________________________________________");
				String qid=tbB.getQid();
				quescount++;
				System.out.println(tbB.getQid()+"\t\t"+tbB.getQuestions()+"\t\t"+tbB.getOptions());
				
				System.out.println("Enter the option:");
				String ans,setans="";
				ans=in.next();
				tb.setQid(qid);
				setans=td.Answers(tb);
				if(ans.equals(setans))
				{
					anscount++;
				}
			}
			marks=(anscount*100)/quescount;
			if(marks>=60)
			{
				System.out.println("You have scored..:"+marks); 
				System.out.println("You have Cleared the Online Exam conducted by ORS...!!");
			}
			else
			{
				System.out.println("You have scored..:"+marks); 
				System.out.println("Sorry!better luck next time..!!");
			}
	}
}
