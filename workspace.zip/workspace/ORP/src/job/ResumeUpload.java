package job;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.inautix.job.ResumeBean;
import com.inautix.job.ResumeDao;
import com.inautix.job.jobAppBean;
import com.inautix.job.jobBean;

public class ResumeUpload 
{
	public static void main(String[] args)
	{
		ResumeDao rd=new ResumeDao();
		ResumeBean rb=new ResumeBean();
		Scanner in = new Scanner(System.in);
		String ApId,FilePath;
		int status;
		System.out.println("Resume Upload...!!!");
		System.out.println("_________________________________");
		System.out.print("Choose your ApId from the below:\t");
		
		List<ResumeBean> jsl = null;
		jsl=rd.ApplicantList();
		Iterator<ResumeBean> ir =  jsl.iterator();
		while(ir.hasNext())
		{
			ResumeBean rB = ir.next();
			System.out.println("\n"+"AppID-"+rB.getApId()+"\n");

		}
		System.out.println("_________________________________");
		System.out.println("Enter your Applicant Id:");
		ApId=in.next();
		rb.setApId(ApId);
		System.out.println("Enter the Resume filepath:");
		FilePath=in.next();
		rb.setFilePath(FilePath);
		
		status = rd.uploadResume(rb);
		
		if(status>0)
		{
			System.out.println("_________________________________");
			System.out.println("Resume Uploaded Successfully...!!");
		}
	}
}
