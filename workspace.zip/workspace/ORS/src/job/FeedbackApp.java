package job;

import java.util.Scanner;

import com.inautix.job.FeedbackBean;
import com.inautix.job.FeedbackDao;

public class FeedbackApp 
{
	public static void main (String[] args)
	{
		FeedbackDao fd=new FeedbackDao();
		FeedbackBean fb=new FeedbackBean();
		Scanner in = new Scanner(System.in);
		String ApId,Description;
		int status;
		System.out.println("Enter the ApId:");
		ApId=in.next();
		fb.setApId(ApId);
		System.out.println("Enter the feedback:");
		Description=in.next();
		fb.setDescription(Description);
		status=fd.createFeedback(fb);
		if(status>0)
		{
			System.out.println("Feedback Updated...!!");
		}
	}

}
