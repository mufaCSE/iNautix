//completed

package com.myapp.servletController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.job.jobBean;
import com.inautix.job.jobDao;

/**
 * Servlet implementation class JobListingServlet
 */
@WebServlet("/JobListingServlet")
public class JobListingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JobListingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String stream=request.getParameter("STREAM");
		jobBean jbe=new jobBean();
		jobDao jD=new jobDao();
		jbe.setStream(stream);
		List<jobBean> jsl = null;
		jsl=jD.searchJob(jbe);
		Iterator<jobBean> ir =  jsl.iterator();
		out.println("<html><head><link rel='stylesheet' href='/ORS/CSSFiles/JobListing.css'></head><body background='/ORS/HTMLFiles/4.jpg'>");
		out.println("<ul><li><a class='active' href='NewLogin1.html'>Home</a></li><li><a href='#about'>About</a></li> <li class='logout'><a href='logout.jsp'>Logout</a></li></ul>");
		out.println("<h3><center>THE JOBS RELATED TO YOUR STREAM</center></h3>");
		out.println("<form action ='/ORS/TestJsp.jsp' method='get'>");
		out.println("<table align='center'>");
		out.println("<tr><th>JOBID</th><th>COMPANY</th><th>POSITION</th><th>SALARY</th></tr>");
		while(ir.hasNext())
		{
			jobBean jbB = ir.next();
			out.println("<tr><td>"+jbB.getJobId()+"</td><td>"+jbB.getCompany()+"</td><td>"+jbB.getPosition()+"</td><td>"+jbB.getSalary()+"</td></tr>");
			
		}
		out.println("<tr><td>EnterCompany</td><td><input type='text' name ='COMPANY'></td></tr>");
		out.println("<tr><td></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type='submit' /><b>TakeTest</b></button></td></tr></table></form></body></html>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
