//completed

package com.myapp.servletController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.job.JobAppDao;
import com.inautix.job.jobAppBean;

/**
 * Servlet implementation class JobApplicantServlets
 */
@WebServlet("/JobApplicantServlets")
public class JobApplicantServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JobApplicantServlets() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
	
			jobAppBean j =new jobAppBean();
			JobAppDao jDao = new JobAppDao();
			String status=null;
			Enumeration paramNames = request.getParameterNames();
			
			
		
			
			
			
			String Name=request.getParameter("APPNAME");
			j.setName(Name);
			
		
			int Age=Integer.parseInt(request.getParameter("AGE"));
			j.setAge(Age);
			
			
			String Qualification=request.getParameter("QUALIFICATION");
			j.setQualifications(Qualification);
			
			
			String Gender=request.getParameter("SEX");
			j.setGender(Gender);
			
			
			String Uname=request.getParameter("UNAME");
			j.setUname(Uname);
			
			
			String pwd=request.getParameter("PASS");
			j.setPwd(pwd);
			
			
			String DoB=request.getParameter("DOB");
			j.setDoB(DoB);
			
			
			String streamdet=request.getParameter("STREAM");
			j.setStream(streamdet);
			
			status=(String)jDao.addJobApp(j);
			if(status!=null)
			{
				
				out.print("<html><body>");
		        out.print("<h1><center> Registeration Details<center></h1>");
		        out.print("<script>alert('NOTE THE APPLICANT ID')</script>");
		        out.println("<b>Applicant Id : <b>"+status);
		        out.println("<form action ='/ORS/HTMLFiles/NewLogin1.html'>");
		        out.println("<table>");
		        out.println("<tr> <th>Parameter Name</th>" + "<th>Parameter Value</th></tr>"); 
		        while(paramNames.hasMoreElements()) 
		        {
		            String paramName = (String)paramNames.nextElement();
		            out.print("<tr><td>" + paramName + "\n<td>");
		            String[] paramValues = request.getParameterValues(paramName);
		            if (paramValues.length == 1) 
		            {
		                String paramValue = paramValues[0];
		                if (paramValue.length() == 0)
		                    out.println("No Value");
		                else
		                    out.println(paramValue);
		            } 
		            else
		            {
		                out.println("<ul>");
		                for(int i=0; i<paramValues.length; i++) 
		                {
		                    out.println("<li>" + paramValues[i] + "</li>");
		                }
		                out.println("</ul>");
		            }
		        }
		    out.println("</table>");
		    out.println("<input type='submit'/>");
		    out.println("</form>");
		    out.println("</body></html>");

			}
			else{  
		        out.print("Sorry Not Registered!");  
		        /*RequestDispatcher rd=request.getRequestDispatcher("../JobApplicant.html");  
		        rd.include(request, response);  */
		                      
		        }  

			
			}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
