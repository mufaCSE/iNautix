package com.inautix.job;

public class EmployerBean {
	
	public String empname;
	public String company;
	public String empuname;
	public String emppwd;
	public String eid;
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getEmpuname() {
		return empuname;
	}
	public void setEmpuname(String empuname) {
		this.empuname = empuname;
	}
	public String getEmppwd() {
		return emppwd;
	}
	public void setEmppwd(String emppwd) {
		this.emppwd = emppwd;
	}
}
