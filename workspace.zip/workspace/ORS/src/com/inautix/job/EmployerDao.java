package com.inautix.job;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EmployerDao {
	static ConnectionManager conn;
	static Statement stmt;
	PreparedStatement pst;
	//Connection con;
	public EmployerDao()
	{
		conn=new ConnectionManager();
		stmt=null;
		pst=null;
	}
	public int getCount()
	{
		String query;
		ResultSet rs=null;
		int count=0;
		try
		{
			
			stmt=conn.connectionHelper().createStatement();
			query="select count(EId) from T_XBBNHG1_Employer";
			rs=stmt.executeQuery(query);
			if(rs.next())
			{
				count=rs.getInt(1);
			}
		}
		catch(SQLException s)
		{
			s.printStackTrace();
		}
		finally
		{
			try {
				conn.connectionHelper().close();
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		return count;
	}
	public  String addJobApp(EmployerBean j)
	{
		String query,EId=null;
		int status=0;
		int count;
		try {
			count=getCount();
			count=101+count;
			EId="E"+count;
			query="insert into T_XBBNHG1_Employer values(?,?,?,?,?)";
			pst=conn.connectionHelper().prepareStatement(query);
			pst.setString(1, EId);
			pst.setString(2, j.getEmpname());
			pst.setString(3, j.getCompany());
			pst.setString(4, j.getEmpuname());
			pst.setString(5, j.getEmppwd());
			
			
			
			pst.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				if(pst!= null)
				pst.close();
				
				if(conn != null)
				  conn.connectionHelper().close();
			}catch(Exception e)
			{
				
			}
		}
		
		return EId;
		}
	public  int EmployerDet(EmployerBean emp)
	{	
		EmployerBean em=new EmployerBean();
		ResultSet rs=null;
		String query;
		int status=0;
		try {
			
			query="select EID from T_XBBNHG1_Employer where Username=? and Password = ?";
			pst=conn.connectionHelper().prepareStatement(query);
			pst.setString(1, emp.getEmpuname());
			pst.setString(2, emp.getEmppwd());
			
			
			
			status=pst.executeUpdate();
			/*if(rs.next())
			{
				em.setEid(rs.getString(1));
			}*/
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				if(pst!= null)
				pst.close();
				
				if(conn != null)
				  conn.connectionHelper().close();
			}catch(Exception e)
			{
				
			}
		}
		
		return status;
		}
}
