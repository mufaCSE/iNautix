package com.inautix.job;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class jobDao 
{
	static ConnectionManager conn;
	static Statement stmt;
	static PreparedStatement pst;
	public jobDao()
	{
		conn=new ConnectionManager();
		stmt=null;
		pst=null;
	}
public static List searchJob(jobBean j){
		
		
		List JobSearchList = null;
		
		ResultSet rs=null;
		try {
			
			 stmt = conn.connectionHelper().createStatement();
			 String searchquery="Select * from T_XBBNHG1_Job where stream =?";
			 JobSearchList=new ArrayList<jobBean>();
			 pst=conn.connectionHelper().prepareStatement(searchquery);
				
			pst.setString(1, j.getStream());
			rs=pst.executeQuery();
			 while(rs.next())
			 {
				jobBean jb =new jobBean();
				jb.setJobId(rs.getString(1));
				jb.setPosition(rs.getString(2));
				jb.setCompany(rs.getString(3));
				jb.setStream(rs.getString(4));
				jb.setSalary(rs.getInt(5));
				
				JobSearchList.add(jb);
				
			 }
			
			
			}
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		finally{
			try {
				if(rs!= null)
				rs.close();
				if(stmt != null)					
				stmt.close();				
				//conn.commit();
				if(conn != null)
				  conn.connectionHelper().close();
			}catch(Exception e)
			{
				
			}
		}
		
			return JobSearchList;
	}
public static List<jobBean> ViewJob(){
	
	
	List JobSearchList = null;
	
	ResultSet rs=null;
	try {
		
		 stmt = conn.connectionHelper().createStatement();
		 String searchquery="Select * from T_XBBNHG1_Job";
		 JobSearchList=new ArrayList<jobBean>();
		 pst=conn.connectionHelper().prepareStatement(searchquery);
			
		
		rs=pst.executeQuery();
		 while(rs.next())
		 {
			jobBean jb =new jobBean();
			jb.setJobId(rs.getString(1));
			jb.setPosition(rs.getString(2));
			jb.setCompany(rs.getString(3));
			jb.setStream(rs.getString(4));
			jb.setSalary(rs.getInt(5));
			
			JobSearchList.add(jb);
			
		 }
		
		
		}
	 catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}		
	finally{
		try {
			if(rs!= null)
			rs.close();
			if(stmt != null)					
			stmt.close();				
			//conn.commit();
			if(conn != null)
			  conn.connectionHelper().close();
		}catch(Exception e)
		{
			
		}
	}
	
		return JobSearchList;
}
public int getCount()
{
	String query;
	ResultSet rs=null;
	int count=0;
	try
	{
		
		stmt=conn.connectionHelper().createStatement();
		query="select count(EId) from T_XBBNHG1_Job";
		rs=stmt.executeQuery(query);
		if(rs.next())
		{
			count=rs.getInt(1);
		}
	}
	catch(SQLException s)
	{
		s.printStackTrace();
	}
	finally
	{
		try {
			conn.connectionHelper().close();
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	return count;
}
public  int addJob(jobBean j)
{
	String query,Jid=null;
	int status=0,count;
	try {
		count=getCount();
		count=101+count;
		Jid="J"+count;
		query="insert into T_XBBNHG1_Job values(?,?,?,?,?,?)";
		pst=conn.connectionHelper().prepareStatement(query);
		pst.setString(1,Jid);
		pst.setString(2, j.getPosition());
		pst.setString(3, j.getCompany());
		pst.setString(4, j.getStream());
		pst.setInt(5, j.getSalary());
		pst.setString(6,j.getEmpId());
		
		
		status=pst.executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally{
		try {
			if(pst!= null)
			pst.close();
			
			if(conn != null)
			  conn.connectionHelper().close();
		}catch(Exception e)
		{
			
		}
	}
	
	return status;
	}
public  int employerDet(jobBean j)
{
	String query;
	int status=0;
	try {
		
		query="select Eid from T_XBBNHG1_Employer where Username=? and Password = ?";
		pst=conn.connectionHelper().prepareStatement(query);
		pst.setString(1, j.getUname());
		pst.setString(2, j.getPwd());
		
		
		
		status=pst.executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally{
		try {
			if(pst!= null)
			pst.close();
			
			if(conn != null)
			  conn.connectionHelper().close();
		}catch(Exception e)
		{
			
		}
	}
	
	return status;
	}
}
