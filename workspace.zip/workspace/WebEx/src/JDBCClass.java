import java.sql.Connection;
import java.sql.DriverManager;

public class JDBCClass {
	//public static void main(String[] args)
	//{ 	
		Connection con = null;
	//	public JDBCClass(){}
		public Connection connectionHelper()
		{
			try
			{
				//Initialize the driver
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

			}catch(Exception e)
			{
				e.printStackTrace();
			}
			return con;
		}
	//}
}
