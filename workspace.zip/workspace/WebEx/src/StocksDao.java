import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StocksDao
{
	public static void main(String[] args)throws Exception
	{
		
		/*try
		{
		
			
			//Initialize the driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}*/
		
		//step 2: Create connection object
		/*Connection con = null;
		try
		{
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
		}catch(SQLException e)
		{
			e.printStackTrace();
		}*/
		//step3 creating statement
		
		try
		{
			Statement stmt = null;
			JDBCClass j = new JDBCClass();
			j.connectionHelper();
			 stmt = j.connectionHelper().createStatement();
			 String searchQuery = "select * from portfolio";
				ResultSet rs = null; 
				rs = stmt.executeQuery(searchQuery);
				while(rs.next())
				{
					String uname = rs.getString("Usrname");
					String pass = rs.getString("Passwd");
					String name = rs.getString("Name");
					
					
					System.out.println("USERNAME:"+uname);
					System.out.println("PASSWORD:"+pass);
					System.out.println("NAME:"+name);
					System.out.println("----------");
				}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
		
	}
}