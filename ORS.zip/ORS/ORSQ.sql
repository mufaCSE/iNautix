create table T_XBBNHG1_JobApp(ApId varchar(10) PRIMARY KEY,Name varchar(26),Age int,Qualifications varchar(10),Gender varchar(7),DoB date);

create table T_XBBNHG1_Job(Jobid varchar(10) primary key,position varchar(26),company varchar(20),stream varchar(20),salary number(6));

create table T_XBBNHG1_Resume(ApId varchar(10),FilePath varchar(100));

alter table T_XBBNHG1_Resume add constraint fk_resume foreign key (ApId) references T_XBBNHG1_JobApp(ApId);

create table T_XBBNHG1_Result(AppId varchar(10),stream varchar(6),Marks int);

create table T_XBBNHG1_Questions(Qid varchar(10) primary key,Questions varchar(1000),Options varchar(100),Stream varchar(6));

create table T_XBBNHG1_Answers(Qid varchar(10),Answer varchar(50));

create table T_XBBNHG1_Employer(EID varchar(10),EmpName varchar(20),Company varchar(20),UserName varchar(20),Password varchar(20));

alter table T_XBBNHG1_Employer add constraint pk_emp primary key (EID);

alter table T_XBBNHG1_Answers add constraint fk_ans foreign key (Qid) references T_XBBNHG1_Questions(Qid);

create table T_XBBNHG1_Feedback(ApId varchar(10),Description varchar(50));

alter table T_XBBNHG1_Feedback add constraint fk_feedback foreign key (ApId) references T_XBBNHG1_JobApp(ApId);

alter table T_XBBNHG1_Questions drop column options;

alter table T_XBBNHG1_JobApp add  Stream varchar(10);

alter table T_XBBNHG1_Job add  EID varchar(10);

alter table T_XBBNHG1_Job add constraint fk_job foreign key (EID) references T_XBBNHG1_Employer(EID);

alter table T_XBBNHG1_Questions add  Option1 varchar(150);

alter table T_XBBNHG1_Questions add  Option2 varchar(150);

alter table T_XBBNHG1_Questions add  Option3 varchar(150);

alter table T_XBBNHG1_Questions add  Option4 varchar(150);

update  T_XBBNHG1_Questions  set Company='iNautix' where Stream='IT';

update  T_XBBNHG1_Questions   set Company='Siemens Ltd.' where Stream='EEE';

update  T_XBBNHG1_Questions   set Company='Nokia' where Stream='ECE';

update  T_XBBNHG1_Questions   set Company='Hyundai' where QID='Q113';

update  T_XBBNHG1_Questions   set Company='Hyundai' where QID='Q115';

update  T_XBBNHG1_Questions   set Company='Hyundai' where QID='Q111';

update  T_XBBNHG1_Questions   set Company='Hyundai' where QID='Q112';

update  T_XBBNHG1_Questions   set Company='Hyundai' where QID='Q114';

update  T_XBBNHG1_Questions   set Company='L&T' where Stream='CIVIL';




update  T_XBBNHG1_Job set company='iNautix'where jobId='J103';

update  T_XBBNHG1_Questions  set option2='Hard disk'where QId='Q125';

update  T_XBBNHG1_Questions  set option3='Magnetic tape'where QId='Q125';

update  T_XBBNHG1_Questions  set option4='ROM'where QId='Q125';





insert into T_XBBNHG1_Job values('J109','AssistantManager','Siemens Ltd.','EEE',25000,'E101');

insert into T_XBBNHG1_Job values('J110','NetworkEngineer','Siemens Ltd.','EEE',45000,'E101');




update T_XBBNHG1_Job set EID='E101' where Stream='IT';

delete T_XBBNHG1_Employer where EID='E103';

delete T_XBBNHG1_JobApp where ApId='A102';

delete T_XBBNHG1_Questions where Qid='Q126';

delete T_XBBNHG1_Answers where Qid='Q126';

delete T_XBBNHG1_Job where Stream='MECH';

select * from T_XBBNHG1_JobApp;

select * from T_XBBNHG1_Job;

delete T_XBBNHG1_Job where JobId='J103';

select * from T_XBBNHG1_Questions;

select * from T_XBBNHG1_Resume;

select * from T_XBBNHG1_Answers;

drop table T_XBBNHG1_Answers;

select * from T_XBBNHG1_Employer;

insert into T_XBBNHG1_Answers values('Q121','Mica Capacitor');

insert into T_XBBNHG1_Answers values('Q122','X - Y plates');

insert into T_XBBNHG1_Answers values('Q123','limitedlt stable');

insert into T_XBBNHG1_Answers values('Q124','Wien bridge');

insert into T_XBBNHG1_Answers values('Q125','Magnetic tape');

insert into T_XBBNHG1_Answers values('Q116','decreases');

insert into T_XBBNHG1_Answers values('Q117','ohms');

insert into T_XBBNHG1_Answers values('Q118','-330�');

insert into T_XBBNHG1_Answers values('Q119','2,000pf');

insert into T_XBBNHG1_Answers values('Q120','0 A');

Select * from T_XBBNHG1_Questions natural join T_XBBNHG1_Answers;

Select * from T_XBBNHG1_Questions natural join T_XBBNHG1_Answers where company='iNautix';

select ApId from T_XBBNHG1_JobApp where Username='hariharan' and Password = 'hariharan'



insert into T_XBBNHG1_Job values('J114','SeniorAppDeveloper','iNautix','IT',75000,'E101');

insert into T_XBBNHG1_Job values('J115','UserDesigner','iNautix','IT',30000,'E101');

insert into T_XBBNHG1_Job values('J116','SeniorManager','iNautix','IT',95000,'E101');



