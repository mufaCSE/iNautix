   package com.inautix.job;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class FeedbackDao {
	  ConnectionManager conn;
	  Statement stmt=null;
	  PreparedStatement pst;
	  public  FeedbackDao()
	  {
			conn=new ConnectionManager();
			stmt=null;
			pst=null;
	  }
  public int createFeedback(FeedbackBean f )
  {
	    String query;
		int status=0;
     try 
     {
     String sql="INSERT INTO T_XBBNNHG1_Feedback values(?,?)";
      pst=conn.connectionHelper().prepareStatement(sql);
      pst.setString(1, f.getApId());
      pst.setString(2, f.getDescription());
      status=pst.executeUpdate();
      
      
    } 
     catch (SQLException e)
     {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    finally
    {
      try 
      {
        if(stmt!=null)
        stmt.close();
        if(conn!=null)
          conn.connectionHelper().close();
       }
      catch (SQLException e) 
      {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
     return status;
    
  } // end of create feedback

}

