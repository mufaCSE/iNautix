package com.inautix.job;

//package com.inautix.job;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.inautix.job.ConnectionManager;

public class JobAppDao {


		static ConnectionManager conn;
		static Statement stmt;
		PreparedStatement pst;
		//Connection con;
		public JobAppDao()
		{
			conn=new ConnectionManager();
			stmt=null;
			pst=null;
		}
/*	public static List jobAppDet(){
		
		//step 3: create statement object 
		List JobList = null;
		
		ResultSet rs=null;
		try {
			
			 stmt = conn.connectionHelper().createStatement();
			 String searchquery="Select * from T_XBBNHG1_JobApp";
			 rs = stmt.executeQuery(searchquery);
			 JobList=new ArrayList<jobAppBean>();
			 while(rs.next())
			 {
				jobAppBean jb =new jobAppBean();
				jb.setApId(rs.getString(1));
				jb.setName(rs.getString(2));
				jb.setAge(rs.getInt(3));
				jb.setQualifications(rs.getString(4));
				jb.setGender(rs.getString(5));
				jb.setDoB(rs.getString(6));
				jb.setUname(rs.getString(6));
				jb.setPwd(rs.getString(6));
				JobList.add(jb);
			 }
			
			
			}
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		finally{
			try {
				if(rs!= null)
				rs.close();
				if(stmt != null)					
				stmt.close();				
				//conn.commit();
				if(conn != null)
				  conn.connectionHelper().close();
			}catch(Exception e)
			{
				
			}
		}
		
			return JobList;
	}*/
		public int getCount()
		{
			String query;
			ResultSet rs=null;
			int count=0;
			try
			{
				
				stmt=conn.connectionHelper().createStatement();
				query="select count(ApId) from T_XBBNHG1_JobApp";
				rs=stmt.executeQuery(query);
				if(rs.next())
				{
					count=rs.getInt(1);
				}
			}
			catch(SQLException s)
			{
				s.printStackTrace();
			}
			finally
			{
				try {
					conn.connectionHelper().close();
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			
			return count;
		}
	
	public  String addJobApp(jobAppBean j)
	{
		String query,ApId=null;
		int status=0;
		int count;
		try {
			count=getCount();
			count=101+count;
			ApId="A"+count;
			query="insert into T_XBBNHG1_JobApp values(?,?,?,?,?,?,?,?,?)";
			pst=conn.connectionHelper().prepareStatement(query);
			pst.setString(1, ApId);
			pst.setString(2, j.getName());
			pst.setInt(3, j.getAge());
			pst.setString(4, j.getQualifications());
			pst.setString(5, j.getGender());
			
			pst.setString(6, j.getUname());
			pst.setString(7, j.getPwd());
			pst.setDate(8, java.sql.Date.valueOf(j.getDoB()));
			pst.setString(9, j.getStream());
			
			pst.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				if(pst!= null)
				pst.close();
				
				if(conn != null)
				  conn.connectionHelper().close();
			}catch(Exception e)
			{
				
			}
		}
		
		return ApId;
		}
	
	
	/*public  int updateJob(jobAppBean j)
	{
		String query;
		int status=0;
		try {
			
			query="update T_XBBNHG1_JobApp set pwd=? where ApId=?";
			pst=conn.connectionHelper().prepareStatement(query);
			
			pst.setString(1, j.getPwd());
			pst.setString(2, j.getApId());
			
			
			status=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				if(pst!= null)
				pst.close();
				if(conn != null)
				  conn.connectionHelper().close();
			}catch(Exception e)
			{
				
			}
		}
		return status;
		}
		*/
	
	public String ApplicantDet(jobAppBean j)
	{	
		
		
		jobAppBean jb=new jobAppBean();
		String query;
		String ApId,AppId = null;
		ResultSet rs=null;
		int status=0;
		try {
			
			query="select ApId from T_XBBNHG1_JobApp where Username=? and Password = ?";
			pst=conn.connectionHelper().prepareStatement(query);
			pst.setString(1, j.getUname());
			pst.setString(2, j.getPwd());
			
			
			
			rs = pst.executeQuery();
			while(rs.next())
			{
				AppId=rs.getString(1);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				if(pst!= null)
				pst.close();
				
				if(conn != null)
				  conn.connectionHelper().close();
			}catch(Exception e)
			{
				
			}
		}
		
		return AppId;
		}
		
	
	
	
	
	
}
