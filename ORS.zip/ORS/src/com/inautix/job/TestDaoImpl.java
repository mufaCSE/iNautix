package com.inautix.job;
import java.sql.Types;
import java.util.Date;
import java.util.*;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;


import com.inautix.job.api.model.Test;
//import com.nxn.tra.api.rowmapper.TestRowMapper;
@Component
public class TestDaoImpl extends JdbcDaoSupport implements ITestDao{

	@Autowired
	public TestDaoImpl(DataSource datasource) {
		// TODO Auto-generated constructor stub
		setDataSource(datasource);
	}
	
	public List<Test> getJobDetails()  {
		// TODO Auto-generated method stub
		List<Test> testObj = new ArrayList<Test>();

	/*	getJdbcTemplate().quer*/
		
		testObj = getJdbcTemplate().query("select * from  T_XBBNHG1_Job",
				new Object[] {}, new TestRowMapper());
		return testObj;

	}

}
