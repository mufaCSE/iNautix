package com.inautix.job;

import java.util.List;

import com.inautix.job.api.model.Test;

public interface ITestDao {
	
	
	public List<Test> getJobDetails() throws Exception;
	
	


}
