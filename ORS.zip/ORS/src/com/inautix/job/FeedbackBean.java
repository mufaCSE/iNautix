package com.inautix.job;

public class FeedbackBean 
{
	public String ApId;
	public String Description;
	public String getApId() {
		return ApId;
	}
	public void setApId(String apId) {
		ApId = apId;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	
}
