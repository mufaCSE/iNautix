package com.inautix.job;

public class TestBean 
{
	public String ApId;
	public String Stream;
	public String Qid;
	public String ans;
	public String Questions;
	public String Option1;
	public String Option2;
	public String Option3;
	public String Option4;
	public String Company;
	public String getOption1() {
		return Option1;
	}
	public void setOption1(String option1) {
		Option1 = option1;
	}
	public String getOption2() {
		return Option2;
	}
	public void setOption2(String option2) {
		Option2 = option2;
	}
	public String getOption3() {
		return Option3;
	}
	public void setOption3(String option3) {
		Option3 = option3;
	}
	public String getOption4() {
		return Option4;
	}
	public void setOption4(String option4) {
		Option4 = option4;
	}
	public String getCompany() {
		return Company;
	}
	public void setCompany(String company) {
		Company = company;
	}
	public String Answers;
	public int Marks;
	
	public String getAns()
	{
		return ans;
	}
	public void setAns(String ans)
	{
		this.ans = ans;
	}
	public String getApId() 
	{
		return ApId;
	}
	public void setApId(String apId)
	{
		ApId = apId;
	}
	public String getStream() 
	{
		return Stream;
	}
	public void setStream(String stream)
	{
		Stream = stream;
	}
	public String getQid() 
	{
		return Qid;
	}
	public void setQid(String qid)
	{
		Qid = qid;
	}
	public String getQuestions() 
	{
		return Questions;
	}
	public void setQuestions(String questions)
	{
		Questions = questions;
	}
	
	public String getAnswers()
	{
		return Answers;
	}
	public String setAnswers(String answers) 
	{
		return Answers = answers;
	}
	public int getMarks() 
	{
		return Marks;
	}
	public void setMarks(int marks)
	{
		Marks = marks;
	}
	
	
}
