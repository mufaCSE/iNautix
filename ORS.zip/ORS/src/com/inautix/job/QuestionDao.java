package com.inautix.job;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class QuestionDao 
{
	static ConnectionManager conn;
	static Statement stmt;
	PreparedStatement pst;
	//Connection con;
			public QuestionDao()
			{
				conn=new ConnectionManager();
				stmt=null;
				pst=null;
			}
	
	public int getCount()
	{
		String query;
		ResultSet rs=null;
		int count=0;
		try
		{
			
			stmt=conn.connectionHelper().createStatement();
			query="select count(QId) from T_XBBNHG1_Questions";
			rs=stmt.executeQuery(query);
				if(rs.next())
				{
					count=rs.getInt(1);
				}
		}
		catch(SQLException s)
			{
				s.printStackTrace();
			}
		finally
		{
			try {
				conn.connectionHelper().close();
				stmt.close();
				} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		return count;
	}
	public  String addQuestion(QuestionBean q)
	{
		String query,QId=null;
		int status=0;
		int count;
		try {
			count=getCount();
			count=101+count;
			QId="Q"+count;
			query="insert into T_XBBNHG1_Questions values(?,?,?,?,?,?,?,?)";
			pst=conn.connectionHelper().prepareStatement(query);
			pst.setString(1, QId);
			pst.setString(2, q.getQuestions());
			pst.setString(3, q.getStream());
			pst.setString(4, q.getCompany());
			pst.setString(5, q.getOption1());
			
			pst.setString(6, q.getOption2());
			pst.setString(7, q.getOption3());
			pst.setString(8, q.getOption4());
			
			
			pst.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				if(pst!= null)
				pst.close();
				
				if(conn != null)
				  conn.connectionHelper().close();
				
			}catch(Exception e)
			{
				
			}
			answerUpdate(QId,q.getAnswer());
			
		}
		
		return QId;
		}
void answerUpdate(String qid,String Answer)
{
	System.out.println("HAi");
	try
	{
	String searchquery="insert into T_XBBNHG1_Answers values(?,?)";
	pst=conn.connectionHelper().prepareStatement(searchquery);
	pst.setString(1, qid);
	pst.setString(2, Answer);
	pst.executeUpdate();

	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			conn.connectionHelper().close();
			stmt.close();
			} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
}

