package com.inautix.job;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inautix.job.*;
/*import com.usermain.parking.Userapp;

import tra.sample.BeanFactory.Triangle;*/

@RestController
@RequestMapping(value = "/reply")
public class ReplyController
{
	
	@RequestMapping(value = "/all" , method = RequestMethod.GET )
	  public List<jobBean> getAllReply() //@RequestParam("uid")String userid //(@PathVariable("id") String testId //
	{ 
		jobDao uapp=new jobDao();
		
		/*BeanFactory factory = new XmlBeanFactory(new FileSystemResource("src/main/webapp/WEB-INF/Spring.xml"));
	      Triangle triangle = (Triangle) factory.getBean("triangle");
	      int a=triangle.getUser_id();
	      System.out.println("INSIDE CONTROLLER:-----"+a);*/
		
	System.out.println("222222 IN CONTROLLER:");
		
		List<jobBean> result=uapp.ViewJob(); //Integer.parseInt(userid)
		
		return result;	
		
		
		
		
}
	
	
}
