package com.inautix.job.api.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@ApiModel
public class Test {
	@ApiModelProperty(position = 1, required = true, value = "testId containing only lowercase letters or numbers")
	
	public String JobId;
	@ApiModelProperty(position = 2, required = true, value = "testId containing only lowercase letters or numbers")

	public String Position;
	@ApiModelProperty(position = 3, required = true, value = "testId containing only lowercase letters or numbers")

	public String Company;
	
	@ApiModelProperty(position = 4, required = true, value = "testId containing only lowercase letters or numbers")

	public String Stream;

	public int Salary;
	public int getSalary() {
		return Salary;
	}

	public void setSalary(int salary) {
		Salary = salary;
	}

	public String getJobId() {
		return JobId;
	}

	public void setJobId(String jobId) {
		JobId = jobId;
	}

	public String getPosition() {
		return Position;
	}

	public void setPosition(String position) {
		Position = position;
	}

	public String getCompany() {
		return Company;
	}

	public void setCompany(String company) {
		Company = company;
	}

	public String getStream() {
		return Stream;
	}

	public void setStream(String stream) {
		Stream = stream;
	}
}
