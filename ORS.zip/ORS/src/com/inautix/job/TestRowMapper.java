package com.inautix.job;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.springframework.jdbc.core.RowMapper;

import com.inautix.job.api.model.Test;


public class TestRowMapper implements RowMapper<Test> {

	public Test mapRow(ResultSet rs, int rownum) throws SQLException {
		// TODO Auto-generated method stub
		
		Test testObj =new Test();
		testObj.setJobId(rs.getString(1));
		testObj.setPosition(rs.getString(2));
		testObj.setCompany(rs.getString(3));
		testObj.setStream(rs.getString(4));
		testObj.setSalary(rs.getInt(5));
	
		
		return testObj;
	}

}
