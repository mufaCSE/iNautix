package com.myapp.servletController;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.job.EmployerDao;
import com.inautix.job.jobBean;
import com.inautix.job.jobDao;

/**
 * Servlet implementation class JobDetailServlet
 */
@WebServlet("/JobDetailServlet")
public class JobDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JobDetailServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		jobDao jD = new jobDao();
		jobBean jbe = new jobBean();
		EmployerDao e=new EmployerDao();
		
		String empid=request.getParameter("EMPID");
		int status1=e.employer(empid);
		if(status1!=0)
		{
		jbe.setEmpId(empid);
		
		String post=request.getParameter("POST");
		jbe.setPosition(post);
		
		String Company=request.getParameter("COMPANY");
		jbe.setCompany(Company);
		
		String Stream=request.getParameter("STREAM");
		jbe.setStream(Stream);
		
		int Salary=Integer.parseInt(request.getParameter("SALARY"));
		jbe.setSalary(Salary);
		
		int status=jD.addJob(jbe);
		if(status!=0)
		{
			out.println("<html><head><link rel='stylesheet' href='/ORS/CSSFiles/JobListing.css'></head><body  background='/ORS/HTMLFiles/4.jpg'>");
			out.println("<ul><li><a class='active' href='NewLogin1.html'>Home</a></li><li><a href='/ORS/HTMLFiles/JobDetail.html'>Add More Job</a></li><li><a href='#about'>About</a></li> <li class='logout'><a href='logout.jsp'>Logout</a></li></ul>");
			out.println("<h3><b><i>JobPosted...!!</i></b></h3>");
			
		}
		else{  
	        out.print("Sorry Not Added!");  
	        RequestDispatcher rd=request.getRequestDispatcher("../JobDetail.html");  
	        rd.include(request, response);  
	                      
	        }  
		}
		else
		{
			out.print("<html><head><style>alert('Enter VAlid Employer Id');</style></head><body></body></html>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
