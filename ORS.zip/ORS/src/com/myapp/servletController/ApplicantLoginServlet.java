/*//completed

package com.myapp.servletController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.job.JobAppDao;
import com.inautix.job.TestBean;
import com.inautix.job.TestDao;
import com.inautix.job.jobAppBean;

*//**
 * Servlet implementation class LoginServlet
 *//*
@WebServlet("/ApplicantLoginServlet")
public class ApplicantLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    *//**
     * Default constructor. 
     *//*
    public ApplicantLoginServlet() {
        // TODO Auto-generated constructor stub
    }

	*//**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 *//*
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		jobAppBean j =new jobAppBean();
		JobAppDao jDao = new JobAppDao();
		int status;
		
		String UName=request.getParameter("APPUNAME");
		j.setUname(UName);
		String Apppass=request.getParameter("APPPASS");
		j.setPwd(Apppass);
		status=jDao.ApplicantDet(j);
		if(status!=0)
		{
			HttpSession session = request.getSession(true);
			session.setAttribute("appname", UName);
			if(session.getAttribute("appname")!=null)
			{
			out.print("<html><head><link rel='stylesheet' href='../CSSFiles/JobApplicant.css'></head><body background='/ORS/HTMLFiles/4.jpg'>");
	        
	        
	  
		
		
	
		out.println("<form class='form' action ='/ORS/JobListingServlet' method='post'>");
		out.print("<h1><center> Welcome!!<center></h1>");
        
		out.println("<table align ='center'>");
		out.println("<tr><td><b>Enter Stream</b></td><td><select name='STREAM'/><option value='IT'>IT</option><option value='MECH'>MECH</option><option value='CIVIL'>CIVIL</option><option value='ECE'>ECE</option><option value='EEE'>EEE</option></td></tr>");
		out.println("<tr><td></td><td><button type='submit' /><b>Search Jobs</b></button></td>");
		out.println("<td><a href='logout.jsp'>LogOut</a></td></tr>");
		out.println("</table></form></body></html>");
			}
			else
			{
				out.println("<a href='/ORS/HTMLFiles/Login.html'>Login to continue</a>");
			}
		
		}
		else{  
	        out.print("Sorry Username or password in correct!!!");  
	       RequestDispatcher rd=request.getRequestDispatcher("/ORS/HTMLFiles/ApplicantLogin.html");  
	        rd.include(request, response);
	                      
	        }  
	}

	*//**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 *//*
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
*/