//completed

package com.myapp.servletController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.job.JobAppDao;
import com.inautix.job.QuestionBean;
import com.inautix.job.QuestionDao;
import com.inautix.job.jobAppBean;

/**
 * Servlet implementation class QuestionServlet
 */
@WebServlet("/QuestionServlet")
public class QuestionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QuestionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
	
			QuestionBean q =new QuestionBean();
			QuestionDao qDao = new QuestionDao();
			String status=null;
			Enumeration paramNames = request.getParameterNames();
			
			
		
			
			
			
			String ques=request.getParameter("Question");
			q.setQuestions(ques);
			
		
			String Stream=request.getParameter("Stream");
			q.setStream(Stream);
			
			
			String Company=request.getParameter("Company");
			q.setCompany(Company);
			
			
			String Option1=request.getParameter("Option1");
			q.setOption1(Option1);
			
			
			String Option2=request.getParameter("Option2");
			q.setOption2(Option2);
			
			
			String Option3=request.getParameter("Option3");
			q.setOption3(Option3);
			
			
			String Option4=request.getParameter("Option4");
			q.setOption4(Option4);
			
			
			String Answer=request.getParameter("Answer");
			q.setAnswer(Answer);
			
			status=(String)qDao.addQuestion(q);
			if(status!=null)
			{
				
				out.print("<html><body>");
		        out.print("<h1><center> Question Details<center></h1>");
		        out.print("<script>alert('NOTE THE APPLICANT ID')</script>");
		        out.println("<b>Question Id : <b>"+status);
		        out.println("<form action ='/ORS/Display.jsp'>");
		        out.println("<table>");
		        out.println("<tr> <th>Parameter Name</th>" + "<th>Parameter Value</th></tr>"); 
		        while(paramNames.hasMoreElements()) 
		        {
		            String paramName = (String)paramNames.nextElement();
		            out.print("<tr><td>" + paramName + "\n<td>");
		            String[] paramValues = request.getParameterValues(paramName);
		            if (paramValues.length == 1) 
		            {
		                String paramValue = paramValues[0];
		                if (paramValue.length() == 0)
		                    out.println("No Value");
		                else
		                    out.println(paramValue);
		            } 
		            else
		            {
		                out.println("<ul>");
		                for(int i=0; i<paramValues.length; i++) 
		                {
		                    out.println("<li>" + paramValues[i] + "</li>");
		                }
		                out.println("</ul>");
		            }
		        }
		    out.println("</table>");
		    out.println("<input type='submit'/>");
		    out.println("</form>");
		    out.println("</body></html>");

			}
			else{  
		        out.print("Sorry Not Updated!");  
		        /*RequestDispatcher rd=request.getRequestDispatcher("../JobApplicant.html");  
		        rd.include(request, response);  */
		                      
		        }  

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
