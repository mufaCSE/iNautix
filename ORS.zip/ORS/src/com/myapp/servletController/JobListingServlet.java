//completed

package com.myapp.servletController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.job.jobBean;
import com.inautix.job.jobDao;

/**
 * Servlet implementation class JobListingServlet
 */
@WebServlet("/JobListingServlet")
public class JobListingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JobListingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession(true);
		if(session.getAttribute("ID")!=null)
		{
		String stream=request.getParameter("STREAM");
		jobBean jbe=new jobBean();
		jobDao jD=new jobDao();
		jbe.setStream(stream);
		List<jobBean> jsl = null;
		jsl=jD.searchJob(jbe);
		Iterator<jobBean> ir =  jsl.iterator();
		Iterator<jobBean> it =  jsl.iterator();
		out.println("<html><head><style>ul{list-style-type: none;margin: 0;padding: 0;overflow: hidden;background-color: rgb(17,126,217);}li {float: left;}li a {display: block;color: white;text-align: center;padding: 14px 16px;text-decoration: none;}li a:hover{background-color: #111;}.colour{color:rgb(17,126,217);padding-left:50px;}.logout{float:right;}th, td {text-align: left;padding: 8px;}tr:nth-child(even){background-color: #f2f2f2;}th{background-color:#00b7ff;color: white;}button{background-color:rgb(17,126,217);color: white;border-radius: 5px;}input[type=text],input[type=password]{padding-top:10px;font-size: 22px;display: inline-block;width: 100%;height: 100%;padding: 5px 10px; background: none;background-image: none;border: 1px solid #a0b3b0;border-radius: 0;}</style></head><body background='/ORS/HTMLFiles/4.jpg'>");
		out.println("<ul><li><a class='active' href='NewLogin1.html'>Home</a></li><li><a href='#about'>About</a></li> <li class='logout'><a href='logout.jsp'>Logout</a></li></ul>");
		out.println("<h3><center>THE JOBS RELATED TO YOUR STREAM</center></h3>");
		out.println("<form action ='/ORS/ResumeUpload.jsp' method='get'>");
		out.println("<table align='center'>");
		out.println("<tr><th>JOBID</th><th>COMPANY</th><th>POSITION</th><th>SALARY</th></tr>");
		while(ir.hasNext())
		{
			jobBean jbB = ir.next();
			out.println("<tr><td>"+jbB.getJobId()+"</td><td>"+jbB.getCompany()+"</td><td>"+jbB.getPosition()+"</td><td>"+jbB.getSalary()+"</td></tr>");
			
		}
		out.println("<tr><td>EnterCompany</td><td><select name='Company'>");
		 while(it.hasNext())
			{
			
				jobBean jbB = it.next();
				out.println("<option value="+ jbB.getCompany() +","+ jbB.getPosition()+ ">"+ jbB.getCompany() +","+ jbB.getPosition() +"</option>");
			}
		 out.println("</select></td></tr>");
		out.println("<tr><td></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type='submit' /><b>UploadResume</b></button></td></table></form></body></html>");
		}
		else
		{
			out.println("<script>alert('Session Expired');window.location.href='/ORS/HTMLFiles/newlogin.html';</script>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
