/*//completed

package com.myapp.servletController;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.job.EmployerBean;
import com.inautix.job.EmployerDao;


*//**
 * Servlet implementation class LoginServlet
 *//*
@WebServlet("/EmployerLoginServlet")
public class EmployerLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    *//**
     * Default constructor. 
     *//*
    public EmployerLoginServlet() {
        // TODO Auto-generated constructor stub
    }

	*//**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 *//*
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		EmployerBean e =new EmployerBean();
		EmployerDao eDao = new EmployerDao();
		int status;
		
		String UName=request.getParameter("EMPUNAME");
		e.setEmpuname(UName);
		String Apppass=request.getParameter("EMPPASS");
		e.setEmppwd(Apppass);
		status=eDao.EmployerDet(e);
		if(status>=1)
		{
			HttpSession session=request.getSession(true);
			session.setAttribute("empuname", UName);
			out.print("<html><body background='/ORS/HTMLFiles/4.jpg'>");
	        out.print("<h1><center> Welcome!!<center></h1>");
	        
	        
	        out.println("<form action ='/ORS/HTMLFiles/JobDetail.html'>");
	        out.println("<table>");
	        out.println("<tr><td><button type='submit' /><b>Click Here to Add Job</b></button></td></tr>");
	        out.println("</table>");
	        out.println("</form>");
	        out.println("</body></html>");
		}
		else{  
			
	        out.print("Sorry Username or password in correct!!!");  
	        RequestDispatcher rd=request.getRequestDispatcher("/HTMLFiles/EmployerLogin.html");  
	        rd.include(request, response); 
	                      
	        }  
	}

	*//**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 *//*
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
*/