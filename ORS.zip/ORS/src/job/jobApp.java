/*package job;


import java.util.List;
import java.util.Scanner;
import java.util.Iterator;
import com.inautix.job.*;

public class jobApp {

	public static void main(String[] args)throws Exception
	{
		// TODO Auto-generated method stub
		JobAppDao jDao = new JobAppDao();
		jobDao jD = new jobDao();
		Scanner in=new Scanner(System.in);
		int choice;
		String status=null;

		List<jobAppBean> jl = null;
				jl=jDao.jobAppDet();
		 Iterator<jobAppBean> itr =  jl.iterator();
		while(itr.hasNext())
		{
			jobAppBean jobBean = itr.next();
			System.out.println(jobBean.getApId()+ "/"+ jobBean.getName());


		}
	System.out.println("1.NewApplicant 2.ExistingApplicant \n");
	
		choice=in.nextInt();
		jobAppBean j =new jobAppBean();
		jobBean jbe = new jobBean();
		String ApId,Name,Qualifications,Gender,DoB,Uname,pwd,stream,streamdet;
		int Age,status1;
		//Insert
		if(choice==1)
		{
				
				
				
				System.out.print("App ID\t");
				ApId=in.next();
				j.setApId(ApId);
				System.out.print("Name\t");
				Name=in.next();
				j.setName(Name);
				System.out.print("Age\t");
				Age=in.nextInt();
				j.setAge(Age);
				System.out.print("Qualifications\t");
				Qualifications=in.next();
				j.setQualifications(Qualifications);
				System.out.print("Gender\t");
				Gender=in.next();
				j.setGender(Gender);
				System.out.print("Uname\t");
				Uname=in.next();
				j.setUname(Uname);
				System.out.print("Password\t");
				pwd=in.next();
				j.setPwd(pwd);
				System.out.print("DoB\t");
				DoB=in.next();
				j.setDoB(DoB);
				
				System.out.print("Stream\t");
				streamdet=in.next();
				j.setStream(streamdet);
				status=jDao.addJobApp(j);
				if(status!=null)
					System.out.println("Insert success");
		}	
				
		if(choice==2)
		{
					System.out.println("Enter Applicant Uname:");
					Uname=in.next();
					j.setUname(Uname);
					System.out.println("Enter Password:");
					pwd=in.next();
					j.setPwd(pwd);
					status1=jDao.ApplicantDet(j);
					if(status1>0)
					{
						System.out.println("Job Searching based of the preferred stream....IT|CIVIL|MECH|ECE|EEE");
						System.out.print("Enter the Stream...:\t");
						stream=in.next();
						jbe.setStream(stream);
						//jD.searchJob(jbe);
						System.out.println("The Jobs related to the stream "+stream+" is as follows..:");
						System.out.println("-------------------------------------------------------------------------");
						List<jobBean> jsl = null;
						jsl=jD.searchJob(jbe);
						Iterator<jobBean> ir =  jsl.iterator();
							while(ir.hasNext())
							{
								jobBean jbB = ir.next();
								System.out.println("\n"+"JOBID-"+jbB.getJobId()+ "\n"+ "POST-"+jbB.getPosition()+"\n"+"SALARY-"+jbB.getSalary()+"\n"+"COMPANY-"+jbB.getCompany());
								System.out.println("\n-------------------------------------------------------------------------");
							}
					}
		}
	}
}
*/