package job;

import java.util.Scanner;

import com.inautix.job.JobAppDao;
import com.inautix.job.jobBean;
import com.inautix.job.jobDao;

public class jobDet 
{
	public static void main(String[] args)throws Exception
	{
		// TODO Auto-generated method stub
		
		jobDao jD = new jobDao();
		jobBean jbe = new jobBean();
		Scanner in=new Scanner(System.in);
		String JobId,Post,comp,str,uname,pwd;
		int Salary,status,status1;
		
		System.out.println("Enter Employer Uname:");
		uname=in.next();
		jbe.setUname(uname);
		System.out.println("Enter Password:");
		pwd=in.next();
		jbe.setPwd(pwd);
		status1=jD.employerDet(jbe);
		if(status1>0)
		{
			System.out.println("Enter the Job details to be Uploaded..: ");
			System.out.println("-----------------------------------------");
			System.out.print("Enter the Job ID:\t");
			JobId=in.next();
			jbe.setJobId(JobId);
			System.out.print("Enter the Post:\t");
			Post=in.next();
			jbe.setPosition(Post);
			System.out.print("Enter the Company:\t");
			comp=in.next();
			jbe.setCompany(comp);
			System.out.print("Enter the Stream:\t");
			str=in.next();
			jbe.setStream(str);
			System.out.print("Enter the Salary:\t");
			Salary=in.nextInt();
			jbe.setSalary(Salary);
			
			status=jD.addJob(jbe);
			if(status>1)
				System.out.println("Insert success");
		}
		else
			System.out.println("Not Permitted..!!");
	}
}
